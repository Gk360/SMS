﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentEntity;
using SMSException;
using SMS_DAL;
using System.IO;
using System.Text.RegularExpressions;
namespace SMS_BLL
{
    /// <summary>
    /// To create the Validation method and to invoke the operations from DAL
    /// </summary>
    public class StudentBLL
    {
        static List<Student> sList = new List<Student>();
        private static bool ValidateStudent( Student student)
        {

            bool validstudent = true;
            StringBuilder message = new StringBuilder();
            if ((student.StudentId <= 0) || (student.StudentId.ToString() == string.Empty))
            {
                validstudent = false;
                message.Append(Environment.NewLine + "student ID Required and cannot be 0");
            }
            //Validating the student ID for matching excatly with 6 digits
            if (!(Regex.IsMatch(student.StudentId.ToString(), @"^[0-9]{6}$")))
            {
                validstudent = false;
                message.Append(Environment.NewLine + "student ID must contain 6 digits only");
            }

            if (!(Regex.IsMatch(student.StudentName, @"^[A-Z][a-z]+$")))
            {
                validstudent = false;
                message.Append(Environment.NewLine + "studentName must contain Characters only");
            }

            if (!(Regex.IsMatch(student.StudentPhoneNo.ToString(), @"^[7-9][0-9]{9}$")))
            {
                validstudent = false;
                message.Append(Environment.NewLine + "student Ph No must contain 10 digits only");
            }

            if ((student.StudentPhoneNo.ToString().Equals(string.Empty)))
            {
                validstudent = false;
                message.Append(Environment.NewLine + "student Ph No is Required");
            }
            if (student.StudentDept.Equals(string.Empty))
            {
                student.StudentDept = "Unknown";
                //student  student1 = new student();
                //student.studentName = student1.studentName ;
            }
            else if (student.StudentName != null)
            {
                if (student.StudentDept == "CSE" || student.StudentDept == "Electronics")
                { validstudent = true; }
                else
                {
                    message.Append(Environment.NewLine + "student Dept must be either CSE or Electronics");
                    validstudent = false;
                }
            }
            if (validstudent == false)
            {
                throw new StudentException(message.ToString());
            }
            return validstudent;
        }

        public bool AddStudentBL(Student student)
        {
            StudentDAL studentOperations = new StudentDAL();

            bool isAdded = false;
            try
            {
                isAdded = studentOperations.AddStudentDAL(student);
                if (isAdded == false)
                {
                    throw new StudentException("Student Details not Added");
                }

            }
            catch (StudentException e)
            {
                throw e;
            }

            return isAdded;
        }

        public List<Student> DisplayStudentBL()
        { 
            StudentDAL studentOperations = new StudentDAL();
            try
            {
                sList = studentOperations.DisplayStudentDAL();
                if (sList.Count <= 0)
                {
                    throw new StudentException("No Records Found!!!");

                }
            }
            catch (StudentException e)
            {
                throw e;
            }

            return sList;
        }

        public void SaveToFile()
        {
            try
            {
                StudentDAL dalobj = new StudentDAL();
                dalobj.SerializeStudent();
            }

            catch (StudentException e)
            { throw e; }

            catch (IOException e)
            { throw e; }
        }

        public List<Student> DisplayFromFile()
        {
            List<Student> sList = new List<Student>();
            try
            {
                StudentDAL dalobj = new StudentDAL();
                
                sList = dalobj.DeserializeStudent();
                if (sList.Count <= 0) throw new StudentException("No Records Found in File");
            }

            catch (StudentException e)
            { throw e; }

            catch (IOException e)
            { throw e; }
          return sList;
        }


    }
}
